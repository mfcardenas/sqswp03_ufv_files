"""
Database of quality scenarios for ISO/IEC 25010 quality attributes.
This file serves as the single source of truth for all scenarios in both Spanish and English.
"""

# Dictionary of quality scenarios with bilingual support
QUALITY_SCENARIOS_DB = [
    {
        "es": {
            "description": "Un sistema de gestión de inventario para una cadena de tiendas debe poder realizar actualizaciones de inventario en tiempo real sin retrasos perceptibles.",
            "category": "Eficiencia de desempeño"
        },
        "en": {
            "description": "An inventory management system for a retail chain should be able to perform real-time inventory updates without perceptible delays.",
            "category": "Performance efficiency"
        }
    },
    {
        "es": {
            "description": "Una aplicación bancaria debe garantizar que todas las transacciones financieras sean seguras y estén protegidas contra accesos no autorizados.",
            "category": "Seguridad"
        },
        "en": {
            "description": "A banking application must ensure that all financial transactions are secure and protected against unauthorized access.",
            "category": "Security"
        }
    },
    {
        "es": {
            "description": "Un sistema de gestión de aprendizaje debe ser fácil de usar para profesores sin experiencia técnica, permitiéndoles crear cursos sin formación adicional.",
            "category": "Usabilidad"
        },
        "en": {
            "description": "A learning management system should be easy to use for teachers without technical experience, allowing them to create courses without additional training.",
            "category": "Usability"
        }
    },
    {
        "es": {
            "description": "Un software de gestión de proyectos debe poder integrarse con herramientas de correo electrónico y calendario para sincronizar automáticamente tareas y reuniones.",
            "category": "Compatibilidad"
        },
        "en": {
            "description": "Project management software should be able to integrate with email and calendar tools to automatically synchronize tasks and meetings.",
            "category": "Compatibility"
        }
    },
    {
        "es": {
            "description": "Una aplicación de comercio electrónico debe tener un tiempo de recuperación menor a 5 minutos después de una falla del sistema para minimizar la pérdida de ventas.",
            "category": "Fiabilidad"
        },
        "en": {
            "description": "An e-commerce application should have a recovery time of less than 5 minutes after a system failure to minimize sales loss.",
            "category": "Reliability"
        }
    },
    {
        "es": {
            "description": "Un sistema de historias clínicas electrónicas debe mantener la consistencia de los datos del paciente incluso cuando múltiples médicos actualicen el registro simultáneamente.",
            "category": "Fiabilidad"
        },
        "en": {
            "description": "An electronic health record system must maintain consistency of patient data even when multiple doctors update the record simultaneously.",
            "category": "Reliability"
        }
    },
    {
        "es": {
            "description": "Un software de análisis de datos debe ser capaz de procesar conjuntos de datos de 1 TB en menos de una hora para permitir decisiones comerciales oportunas.",
            "category": "Eficiencia de desempeño"
        },
        "en": {
            "description": "Data analysis software should be able to process 1 TB datasets in less than one hour to enable timely business decisions.",
            "category": "Performance efficiency"
        }
    },
    {
        "es": {
            "description": "Un sistema de autenticación debe proteger contra ataques de fuerza bruta limitando los intentos de inicio de sesión y utilizando verificación de dos factores.",
            "category": "Seguridad"
        },
        "en": {
            "description": "An authentication system should protect against brute force attacks by limiting login attempts and using two-factor verification.",
            "category": "Security"
        }
    },
    {
        "es": {
            "description": "Un sistema de gestión de contenidos debe permitir a los editores modificar la estructura del sitio web sin requerir conocimientos de programación.",
            "category": "Usabilidad"
        },
        "en": {
            "description": "A content management system should allow editors to modify website structure without requiring programming knowledge.",
            "category": "Usability"
        }
    },
    {
        "es": {
            "description": "Una aplicación móvil debe funcionar correctamente en diferentes versiones de sistemas operativos, desde Android 8 hasta la versión más reciente.",
            "category": "Portabilidad"
        },
        "en": {
            "description": "A mobile application should function correctly on different operating system versions, from Android 8 to the most recent version.",
            "category": "Portability"
        }
    },
    {
        "es": {
            "description": "Un sistema de control de tráfico debe tener un tiempo medio entre fallos (MTBF) de al menos 10,000 horas para garantizar la seguridad vial.",
            "category": "Fiabilidad"
        },
        "en": {
            "description": "A traffic control system should have a mean time between failures (MTBF) of at least 10,000 hours to ensure road safety.",
            "category": "Reliability"
        }
    },
    {
        "es": {
            "description": "Un software de edición de video debe utilizar eficientemente los recursos del sistema para evitar que la computadora se ralentice durante el procesamiento de videos de alta resolución.",
            "category": "Eficiencia de desempeño"
        },
        "en": {
            "description": "Video editing software should efficiently use system resources to prevent the computer from slowing down while processing high-resolution videos.",
            "category": "Performance efficiency"
        }
    },
    {
        "es": {
            "description": "Una plataforma de pagos online debe cifrar la información de la tarjeta de crédito utilizando estándares actualizados para prevenir el robo de datos.",
            "category": "Seguridad"
        },
        "en": {
            "description": "An online payment platform should encrypt credit card information using up-to-date standards to prevent data theft.",
            "category": "Security"
        }
    },
    {
        "es": {
            "description": "Un software de diseño arquitectónico debe proporcionar retroalimentación visual inmediata cuando los usuarios modifiquen elementos de diseño para una experiencia intuitiva.",
            "category": "Usabilidad"
        },
        "en": {
            "description": "Architectural design software should provide immediate visual feedback when users modify design elements for an intuitive experience.",
            "category": "Usability"
        }
    },
    {
        "es": {
            "description": "Un sistema de automatización industrial debe poder comunicarse con equipos de diferentes fabricantes utilizando protocolos estándar.",
            "category": "Compatibilidad"
        },
        "en": {
            "description": "An industrial automation system should be able to communicate with equipment from different manufacturers using standard protocols.",
            "category": "Compatibility"
        }
    },
    {
        "es": {
            "description": "Una aplicación de videoconferencia debe mantener la sincronización de audio y video incluso con conexiones a internet inestables.",
            "category": "Fiabilidad"
        },
        "en": {
            "description": "A videoconferencing application should maintain audio and video synchronization even with unstable internet connections.",
            "category": "Reliability"
        }
    },
    {
        "es": {
            "description": "Un software de renderizado 3D debe aprovechar la aceleración por hardware para maximizar la velocidad de generación de imágenes complejas.",
            "category": "Eficiencia de desempeño"
        },
        "en": {
            "description": "3D rendering software should leverage hardware acceleration to maximize the speed of generating complex images.",
            "category": "Performance efficiency"
        }
    },
    {
        "es": {
            "description": "Un sistema de votación electrónica debe implementar medidas para prevenir la manipulación de votos y garantizar la integridad del proceso electoral.",
            "category": "Seguridad"
        },
        "en": {
            "description": "An electronic voting system should implement measures to prevent vote tampering and ensure the integrity of the electoral process.",
            "category": "Security"
        }
    },
    {
        "es": {
            "description": "Una aplicación de navegación debe proporcionar instrucciones claras y oportunas para ayudar a los conductores a tomar decisiones rápidas en el tráfico.",
            "category": "Usabilidad"
        },
        "en": {
            "description": "A navigation application should provide clear and timely instructions to help drivers make quick decisions in traffic.",
            "category": "Usability"
        }
    },
    {
        "es": {
            "description": "Un software de gestión empresarial debe poder exportar datos en formatos compatibles con herramientas de análisis como Excel y Power BI.",
            "category": "Compatibilidad"
        },
        "en": {
            "description": "Business management software should be able to export data in formats compatible with analysis tools such as Excel and Power BI.",
            "category": "Compatibility"
        }
    },
    {
        "es": {
            "description": "Una plataforma de streaming debe mantener la calidad del servicio incluso durante picos de tráfico en eventos importantes.",
            "category": "Fiabilidad"
        },
        "en": {
            "description": "A streaming platform should maintain service quality even during traffic spikes during important events.",
            "category": "Reliability"
        }
    },
    {
        "es": {
            "description": "Un sistema de reserva de vuelos debe procesar transacciones simultáneas de miles de usuarios sin degradación del rendimiento durante ventas especiales.",
            "category": "Eficiencia de desempeño"
        },
        "en": {
            "description": "A flight booking system should process simultaneous transactions from thousands of users without performance degradation during special sales.",
            "category": "Performance efficiency"
        }
    },
    {
        "es": {
            "description": "Una aplicación de banca móvil debe implementar verificación biométrica para autorizar transacciones sensibles y proteger la información financiera del usuario.",
            "category": "Seguridad"
        },
        "en": {
            "description": "A mobile banking application should implement biometric verification to authorize sensitive transactions and protect user financial information.",
            "category": "Security"
        }
    },
    {
        "es": {
            "description": "Un software de gestión de tareas debe ofrecer opciones de personalización que permitan a los usuarios adaptar la interfaz según sus preferencias y flujos de trabajo.",
            "category": "Usabilidad"
        },
        "en": {
            "description": "Task management software should offer customization options that allow users to adapt the interface according to their preferences and workflows.",
            "category": "Usability"
        }
    },
    {
        "es": {
            "description": "Un sistema de almacenamiento en la nube debe ser compatible con diferentes dispositivos y sistemas operativos para permitir el acceso a los archivos desde cualquier plataforma.",
            "category": "Compatibilidad"
        },
        "en": {
            "description": "A cloud storage system should be compatible with different devices and operating systems to allow file access from any platform.",
            "category": "Compatibility"
        }
    },
    {
        "es": {
            "description": "Un software médico debe realizar copias de seguridad automáticas de la información crítica del paciente para evitar pérdidas de datos en caso de fallos del sistema.",
            "category": "Fiabilidad"
        },
        "en": {
            "description": "Medical software should perform automatic backups of critical patient information to prevent data loss in case of system failures.",
            "category": "Reliability"
        }
    },
    {
        "es": {
            "description": "Un motor de búsqueda debe devolver resultados relevantes en menos de 500 milisegundos para proporcionar una experiencia de usuario fluida.",
            "category": "Eficiencia de desempeño"
        },
        "en": {
            "description": "A search engine should return relevant results in less than 500 milliseconds to provide a smooth user experience.",
            "category": "Performance efficiency"
        }
    },
    {
        "es": {
            "description": "Un sistema de gestión de identidades debe implementar protección contra el robo de sesiones mediante tokens de seguridad y tiempos de expiración adecuados.",
            "category": "Seguridad"
        },
        "en": {
            "description": "An identity management system should implement protection against session hijacking using security tokens and appropriate expiration times.",
            "category": "Security"
        }
    },
    {
        "es": {
            "description": "Una aplicación de edición de fotografías debe ofrecer una interfaz intuitiva con herramientas claramente etiquetadas y accesibles para usuarios novatos.",
            "category": "Usabilidad"
        },
        "en": {
            "description": "A photo editing application should offer an intuitive interface with clearly labeled and accessible tools for novice users.",
            "category": "Usability"
        }
    },
    {
        "es": {
            "description": "Un software de colaboración debe funcionar correctamente con diferentes navegadores web y sus distintas versiones para garantizar la accesibilidad universal.",
            "category": "Portabilidad"
        },
        "en": {
            "description": "Collaboration software should function correctly with different web browsers and their various versions to ensure universal accessibility.",
            "category": "Portability"
        }
    }
]

def get_random_scenarios(num_scenarios=5, language="es"):
    """
    Return a random selection of scenarios in the specified language.
    
    Args:
        num_scenarios (int): Number of scenarios to return.
        language (str): Language code ('es' for Spanish, 'en' for English).
        
    Returns:
        list: A list of selected scenarios in the specified language.
    """
    import random
    
    # Ensure we don't try to get more scenarios than exist
    num_to_return = min(num_scenarios, len(QUALITY_SCENARIOS_DB))
    
    # Select random scenarios
    selected_scenarios = random.sample(QUALITY_SCENARIOS_DB, num_to_return)
    
    # Extract only the requested language part
    return [scenario[language] for scenario in selected_scenarios]

def get_database_stats():
    """
    Return statistics about the database.
    
    Returns:
        dict: A dictionary with database statistics.
    """
    return {
        "total_scenarios": len(QUALITY_SCENARIOS_DB),
        "languages": ["es", "en"],
    }

# If this script is run directly, print some information about the database
if __name__ == "__main__":
    stats = get_database_stats()
    print(f"Quality Scenarios Database contains {stats['total_scenarios']} scenarios.")
    print(f"Available languages: {', '.join(stats['languages'])}")
    
    # Example usage
    print("\nExample of 3 scenarios in Spanish:")
    for i, scenario in enumerate(get_random_scenarios(3, "es"), 1):
        print(f"{i}. {scenario['description']} (Categoría: {scenario['category']})")
    
    print("\nExample of 3 scenarios in English:")
    for i, scenario in enumerate(get_random_scenarios(3, "en"), 1):
        print(f"{i}. {scenario['description']} (Category: {scenario['category']})")